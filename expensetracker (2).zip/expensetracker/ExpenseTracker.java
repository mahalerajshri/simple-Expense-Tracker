import java.util.ArrayList;
import java.util.Scanner;

public class ExpenseTracker {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Expense> expenses = ExpenseStorage.loadExpenses();

        while (true) {
            printMenu();
            int choice = getUserChoice(scanner);

            switch (choice) {
                case 1:
                    addExpense(scanner, expenses);
                    break;
                case 2:
                    viewExpenses(expenses);
                    break;
                case 3:
                    deleteExpense(scanner, expenses);
                    break;
                case 4:
                    searchExpenses(scanner, expenses);
                    break;
                case 5:
                    calculateTotal(expenses);
                    break;
                case 6:
                    System.out.println("Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Please select from the menu.");
            }
        }
    }

    private static void printMenu() {
        System.out.println("\n==== Expense Tracker Menu ====");
        System.out.println("1. Add Expense");
        System.out.println("2. View Expenses");
        System.out.println("3. Delete Expense");
        System.out.println("4. Search Expenses");
        System.out.println("5. Calculate Total Expenses");
        System.out.println("6. Exit");
        System.out.print("Enter your choice: ");
    }

    private static int getUserChoice(Scanner scanner) {
        try {
            return scanner.nextInt();
        } catch (Exception e) {
            scanner.nextLine(); // Clear invalid input
            return -1; // Return invalid choice
        }
    }

    private static void addExpense(Scanner scanner, ArrayList<Expense> expenses) {
        System.out.print("Enter date (YYYY-MM-DD): ");
        String date = scanner.next();
        scanner.nextLine(); // Consume newline left over

        System.out.print("Enter description: ");
        String desc = scanner.nextLine();

        System.out.print("Enter amount: ");
        double amount;
        try {
            amount = scanner.nextDouble();
        } catch (Exception e) {
            System.out.println("Invalid amount. Expense not added.");
            scanner.nextLine();
            return;
        }

        expenses.add(new Expense(date, desc, amount));
        ExpenseStorage.saveExpenses(expenses);
        System.out.println("Expense added successfully.");
    }

    private static void viewExpenses(ArrayList<Expense> expenses) {
        if (expenses.isEmpty()) {
            System.out.println("No expenses to display.");
            return;
        }
        System.out.printf("%-15s %-30s %-10s%n", "Date", "Description", "Amount");
        System.out.println("-------------------------------------------------------------");
        for (Expense e : expenses) {
            System.out.println(e);
        }
    }

    private static void deleteExpense(Scanner scanner, ArrayList<Expense> expenses) {
        if (expenses.isEmpty()) {
            System.out.println("No expenses to delete.");
            return;
        }
        viewExpenses(expenses);
        System.out.print("Enter the number of the expense to delete: ");
        int index = scanner.nextInt() - 1;

        if (index >= 0 && index < expenses.size()) {
            expenses.remove(index);
            ExpenseStorage.saveExpenses(expenses);
            System.out.println("Expense deleted successfully.");
        } else {
            System.out.println("Invalid index. No expense deleted.");
        }
    }

    private static void searchExpenses(Scanner scanner, ArrayList<Expense> expenses) {
        System.out.print("Enter keyword to search (date or description): ");
        String keyword = scanner.next();
        boolean found = false;

        System.out.printf("%-15s %-30s %-10s%n", "Date", "Description", "Amount");
        System.out.println("-------------------------------------------------------------");
        for (Expense e : expenses) {
            if (e.getDate().contains(keyword) || e.getDescription().toLowerCase().contains(keyword.toLowerCase())) {
                System.out.println(e);
                found = true;
            }
        }

        if (!found) {
            System.out.println("No matching expenses found.");
        }
    }

    private static void calculateTotal(ArrayList<Expense> expenses) {
        double total = 0;
        for (Expense e : expenses) {
            total += e.getAmount();
        }
        System.out.printf("Total Expenses: $%.2f%n", total);
    }
}
