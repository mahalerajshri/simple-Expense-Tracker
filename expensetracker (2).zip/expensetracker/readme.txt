use this command to run code
javac Expense.java ExpenseStorage.java ExpenseTracker.java
java ExpenseTracker