import java.io.*;
import java.util.ArrayList;

public class ExpenseStorage {
    private static final String FILENAME = "expenses.txt";
    private static final String HEADER = String.format("%-15s %-30s %-10s", "Date", "Description", "Amount");

    public static void saveExpenses(ArrayList<Expense> expenses) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(FILENAME))) {
            // Write header
            writer.println(HEADER);
            writer.println("-------------------------------------------------------------");

            // Write each expense
            for (Expense e : expenses) {
                writer.println(String.format("%-15s %-30s $%-10.2f", e.getDate(), e.getDescription(), e.getAmount()));
            }

            System.out.println("Expenses saved successfully to " + FILENAME);
        } catch (IOException e) {
            System.out.println("Error saving expenses: " + e.getMessage());
        }
    }

    public static ArrayList<Expense> loadExpenses() {
        ArrayList<Expense> expenses = new ArrayList<>();
        File file = new File(FILENAME);
        if (!file.exists()) {
            return expenses;
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(FILENAME))) {
            String line;
            boolean skipHeader = true;

            while ((line = reader.readLine()) != null) {
                // Skip the header lines
                if (skipHeader) {
                    if (line.startsWith("Date")) continue;
                    if (line.startsWith("-")) {
                        skipHeader = false;
                        continue;
                    }
                }

                // Parse data rows
                String[] parts = line.trim().split("\\s{2,}");
                if (parts.length == 3) {
                    try {
                        String date = parts[0];
                        String description = parts[1];
                        double amount = Double.parseDouble(parts[2].replace("$", ""));
                        expenses.add(new Expense(date, description, amount));
                    } catch (NumberFormatException ex) {
                        System.out.println("Skipping invalid expense entry: " + line);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading expenses: " + e.getMessage());
        }
        return expenses;
    }
}
